// ------------------------Récupération et affichage de l'Id de la commande-----------------

const order = ()=> {
    let orderId = JSON.parse(localStorage.getItem("orderId").split("-").join(''));
    displayOrderId = document.getElementById("orderId").textContent = `${orderId}`;
}

order();

// ------------------------Effacer données dans localstorage-----------------


const deleteLocalstorage = ()=> {
    localStorage.removeItem("product");
    localStorage.removeItem("orderId");
}

deleteLocalstorage()